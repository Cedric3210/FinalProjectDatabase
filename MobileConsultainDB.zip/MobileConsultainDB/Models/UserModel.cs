﻿using Consultation.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UM_Consultation_App_MAUI.Models
{
    public class UserModel
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public UserType UserType { get; set; }
    }
}
