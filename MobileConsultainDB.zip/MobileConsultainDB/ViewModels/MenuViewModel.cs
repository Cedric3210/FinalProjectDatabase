﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UM_Consultation_App_MAUI.ViewModels
{
    public class MenuViewModel
    {
        public string Name { get; set; } = "Naive, Allen Vincent";
        public string Email { get; set; } = "engrng";
        public string Password { get; set; } = "***"; 
    }
}
