namespace UM_Consultation_App_MAUI.Views.StudentView;

public partial class HomePage : ContentPage
{
	public HomePage()
	{
		InitializeComponent();
	}
}